using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attack : MonoBehaviour
{
    public GameObject explosionEffect; // Tambahkan ini di Inspector untuk efek partikel
    public AudioClip explosionSound; // Tambahkan ini di Inspector untuk suara

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("OnTriggerEnter2D called with: " + collision.gameObject.name); // Log untuk debugging
        
        if (collision != null && collision.gameObject.CompareTag("Enemy"))
        {
            Debug.Log("Collided with enemy: " + collision.gameObject.name); // Log untuk memastikan tag benar
            
            if (explosionEffect != null)
            {
                Instantiate(explosionEffect, transform.position, transform.rotation);
            }

            if (explosionSound != null)
            {
                AudioSource.PlayClipAtPoint(explosionSound, transform.position);
            }

            Destroy(collision.gameObject); 
            Destroy(gameObject); 
        }
    }
}
